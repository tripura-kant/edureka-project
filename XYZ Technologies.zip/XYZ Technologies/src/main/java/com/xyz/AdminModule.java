package com.xyz;

public class AdminModule {
	private int user_id;
	private String user_name;
	private String user_emailId;
	private int age;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_emailId() {
		return user_emailId;
	}
	public void setUser_emailId(String user_emailId) {
		this.user_emailId = user_emailId;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	

}
